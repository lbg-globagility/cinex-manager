-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: localhost    Database: azynema_fsm2
-- ------------------------------------------------------
-- Server version	5.7.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `patrons_active`
--

DROP TABLE IF EXISTS `patrons_active`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `patrons_active` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patron_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patrons_active`
--

LOCK TABLES `patrons_active` WRITE;
/*!40000 ALTER TABLE `patrons_active` DISABLE KEYS */;
INSERT INTO `patrons_active` VALUES (1,26),(2,14),(3,22),(4,77),(5,59),(6,37),(7,48);
/*!40000 ALTER TABLE `patrons_active` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'azynema_fsm2'
--
/*!50003 DROP FUNCTION IF EXISTS `CurrentDateTime` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `CurrentDateTime`() RETURNS datetime
BEGIN
RETURN NOW();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reports_cinema_sales_ticket_type_sold` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `reports_cinema_sales_ticket_type_sold`(_start_date DATETIME, _end_date DATETIME)
BEGIN
DECLARE _report_name VARCHAR(60);
DECLARE _dt DATETIME;
DECLARE _date VARCHAR(20);
DECLARE _time VARCHAR(20);
SELECT `name` INTO _report_name FROM report WHERE id = 9;
SET _dt = NOW();
SET _date = DATE_FORMAT(_dt, '%m/%d/%Y');
SET _time = DATE_FORMAT(_dt, '%h:%i %p');
SELECT CONCAT('Date:  ', _date) as currentdate, CONCAT('Time:  ',_time) as currenttime, 
'' AS establishmentname,
IFNULL(_report_name, '') AS reportname, 
 CONCAT('From ', DATE_FORMAT(_start_date, '%m/%d/%Y'), ' to ', DATE_FORMAT(_end_date, '%m/%d/%Y')) AS daterange
FROM dual;
SELECT f.name,  d.code, d.name,  a.price,  COUNT(a.cinema_seat_id), SUM(a.price) FROM movies_schedule_list_reserved_seat a, movies_schedule_list b, 
movies_schedule c, patrons d, cinema f
WHERE a.movies_schedule_list_id = b.id AND b.movies_schedule_id = c.id AND a.patron_id = d.id AND cinema_id = f.id
AND c.movie_date BETWEEN _start_date AND _end_date GROUP BY cinema_id, a.patron_id, a.price 
ORDER BY f.in_order, d.name, a.price;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reports_cinema_sales_ticket_type_sold_per_movie_title` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `reports_cinema_sales_ticket_type_sold_per_movie_title`(_start_date DATETIME, _end_date DATETIME)
BEGIN
DECLARE _report_name VARCHAR(60);
DECLARE _dt DATETIME;
DECLARE _date VARCHAR(20);
DECLARE _time VARCHAR(20);
SELECT `name` INTO _report_name FROM report WHERE id = 10;
SET _dt = NOW();
SET _date = DATE_FORMAT(_dt, '%m/%d/%Y');
SET _time = DATE_FORMAT(_dt, '%h:%i %p');
SELECT CONCAT('Date:  ', _date) as currentdate, CONCAT('Time:  ',_time) as currenttime, 
'' AS establishmentname,
IFNULL(_report_name, '') AS reportname, 
 CONCAT('From ', DATE_FORMAT(_start_date, '%m/%d/%Y'), ' to ', DATE_FORMAT(_end_date, '%m/%d/%Y')) AS daterange
FROM dual;
SELECT f.name,  g.title, d.code, d.name, a.price, COUNT(a.cinema_seat_id), SUM(a.price) FROM movies_schedule_list_reserved_seat a, movies_schedule_list b, 
movies_schedule c, patrons d, cinema f, movies g
WHERE a.movies_schedule_list_id = b.id AND b.movies_schedule_id = c.id AND a.patron_id = d.id AND cinema_id = f.id
AND c.movie_id = g.id AND c.movie_date BETWEEN _start_date AND _end_date GROUP BY cinema_id, g.id, a.patron_id, a.price 
ORDER BY f.in_order, g.title, d.name, a.price;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reports_daily_box_office` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `reports_daily_box_office`(_start_date DATETIME, _cinema_id INT, _movie_id INT)
BEGIN
DECLARE _cinema_name VARCHAR(100);
DECLARE _movie_name VARCHAR(100);
DECLARE _report_name VARCHAR(60);
DECLARE _dt DATETIME;
DECLARE _date VARCHAR(20);
DECLARE _time VARCHAR(20);
SELECT `name` INTO _cinema_name FROM cinema WHERE id = _cinema_id;
SELECT title INTO _movie_name FROM movies WHERE id = _movie_id;
SELECT `name` INTO _report_name FROM report WHERE id = 8;
SET _dt = NOW();
SET _date = DATE_FORMAT(_dt, '%m/%d/%Y');
SET _time = DATE_FORMAT(_dt, '%h:%i %p');
SELECT CONCAT('Date:  ', _date) as currentdate, CONCAT('Time:  ',_time) as currenttime, 
'' AS establishmentname,
IFNULL(_report_name, '') AS reportname, IFNULL(_cinema_name, '') AS cinemaname, IFNULL(_movie_name, '') AS moviename,
DATE_FORMAT(_start_date, '%m/%d/%Y') AS startdate, 'Manager :      ___________________' as manager FROM dual;
SELECT COUNT(cinema_seat_id) totalquantity, SUM(price) totalprice, MIN(b.start_time) start_time, MAX(b.end_time) end_time FROM movies_schedule_list_reserved_seat a, movies_schedule_list b, movies_schedule c, patrons d
WHERE a.movies_schedule_list_id = b.id AND b.movies_schedule_id = c.id AND a.patron_id = d.id
AND c.movie_date = _start_date AND cinema_id = _cinema_id AND movie_id = _movie_id;
SELECT d.name, IFNULL(COUNT(cinema_seat_id), 0), a.price, IFNULL(SUM(price), 0) FROM movies_schedule_list_reserved_seat a, movies_schedule_list b, movies_schedule c, patrons d
WHERE a.movies_schedule_list_id = b.id AND b.movies_schedule_id = c.id AND a.patron_id = d.id
AND c.movie_date = _start_date AND cinema_id = _cinema_id AND movie_id = _movie_id
GROUP BY a.patron_id, a.price ORDER BY d.name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reports_daily_sales_distributor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `reports_daily_sales_distributor`(_distributorid INT, _start_date DATETIME)
BEGIN
DECLARE _distributorname VARCHAR(100);
DECLARE _report_name VARCHAR(60);
DECLARE _dt DATETIME;
DECLARE _date VARCHAR(20);
DECLARE _time VARCHAR(20);
SELECT `name` INTO _distributorname FROM distributor WHERE id = _distributorid;
SELECT `name` INTO _report_name FROM report WHERE id = 1;
SET _dt = NOW();
SET _date = DATE_FORMAT(_dt, '%m/%d/%Y');
SET _time = DATE_FORMAT(_dt, '%h:%i %p');
SELECT CONCAT('Date:  ', _date) as currentdate, CONCAT('Time:  ',_time) as currenttime, 
'' AS establishmentname,
IFNULL(_report_name, '') AS reportname, IFNULL(_distributorname, '') AS distributorname, 
 CONCAT('For ', DATE_FORMAT(_start_date, '%m/%d/%Y')) AS fordate FROM dual;
SELECT e.code, e.title, COUNT(a.cinema_seat_id), SUM( a.price) FROM movies_schedule_list_reserved_seat a, ticket b, 
movies_schedule_list c, movies_schedule d, movies e
 WHERE a.ticket_id = b.id AND a.movies_schedule_list_id = c.id AND c.movies_schedule_id = d.movie_id
 AND d.movie_date = _start_date
 AND d.movie_id = e.id AND e.dist_id = _distributorid GROUP BY e.code, e.title ORDER BY e.code;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reports_movie_sales` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `reports_movie_sales`(_start_date DATETIME, _end_date DATETIME)
BEGIN
DECLARE _report_name VARCHAR(60);
DECLARE _dt DATETIME;
DECLARE _date VARCHAR(20);
DECLARE _time VARCHAR(20);
SELECT `name` INTO _report_name FROM report WHERE id = 2;
SET _dt = NOW();
SET _date = DATE_FORMAT(_dt, '%m/%d/%Y');
SET _time = DATE_FORMAT(_dt, '%h:%i %p');
SELECT CONCAT('Date:  ', _date) as currentdate, CONCAT('Time:  ',_time) as currenttime, 
'' AS establishmentname,
IFNULL(_report_name, '') AS reportname, 
 CONCAT('From ', DATE_FORMAT(_start_date, '%m/%d/%Y'), ' to ', DATE_FORMAT(_end_date, '%m/%d/%Y')) AS daterange
FROM dual;
SELECT e.code, e.title, e.no_of_days, f.no_of_screenings, total_seats_taken, total_available_seats,  total_ticket_sales,
(total_seats_taken/total_available_seats) * 100 util
   FROM (
SELECT a.id, code, title, rating_id, COUNT(movie_date) no_of_days FROM movies a, movies_schedule b 
WHERE a.id = b.movie_id
AND b.movie_date BETWEEN _start_date AND _end_date GROUP BY a.id ) e,
(
SELECT movie_id, COUNT(c.id) no_of_screenings FROM movies_schedule_list c, movies_schedule d WHERE c.movies_schedule_id =d.id AND
 d.movie_date BETWEEN  _start_date AND _end_date GROUP BY movie_id ) f,
(
SELECT j.movie_id, COUNT(h.cinema_seat_id) total_seats_taken, SUM(h.price) total_ticket_sales FROM 
movies_schedule_list_reserved_seat h, movies_schedule_list i, movies_schedule j 
WHERE h.movies_schedule_list_id = i.id AND i.movies_schedule_id = j.id AND
 j.movie_date BETWEEN  _start_date AND _end_date  GROUP BY movie_id
) g,
(
	SELECT movie_id, SUM(available_seats) total_available_seats FROM (
	SELECT movie_id, n.capacity * COUNT(l.id) available_seats FROM movies_schedule_list l, movies_schedule m, cinema n
	WHERE l.movies_schedule_id =m.id AND m.cinema_id = n.id AND
	m.movie_date BETWEEN  _start_date AND _end_date GROUP BY movie_id, cinema_id) o GROUP BY movie_id
) k
WHERE e.id = f.movie_id AND e.id = g.movie_id AND e.id = k.movie_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reports_pos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `reports_pos`(_start_date DATETIME)
BEGIN
DECLARE _report_name VARCHAR(60);
DECLARE _dt DATETIME;
DECLARE _date VARCHAR(20);
DECLARE _time VARCHAR(20);
SELECT `name` INTO _report_name FROM report WHERE id = 19;
SET _dt = NOW();
SET _date = DATE_FORMAT(_dt, '%m/%d/%Y');
SET _time = DATE_FORMAT(_dt, '%h:%i %p');
SELECT CONCAT('Date:  ', _date) as currentdate, CONCAT('Time:  ',_time) as currenttime, 
'' AS establishmentname,
IFNULL(_report_name, '') AS reportname, 
DATE_FORMAT(_start_date, '%m/%d/%Y') AS fordate, 
IFNULL(SUM(a.price), 0) AS voidamount
FROM movies_schedule_list_reserved_seat a, movies_schedule_list b, movies_schedule c, ticket d
WHERE a.movies_schedule_list_id = b.id AND b.movies_schedule_id = c.id 
AND a.ticket_id = d.id
AND c.movie_date = _start_date AND a.status = 0;
SELECT IFNULL(COUNT(a.id), 0), IFNULL(SUM(a.price), 0) 
FROM movies_schedule_list_reserved_seat a, movies_schedule_list b, movies_schedule c, ticket e 
WHERE a.movies_schedule_list_id = b.id AND b.movies_schedule_id = c.id  AND a.ticket_id = e.id
AND c.movie_date = _start_date AND a.status = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reports_summary_daily_cinema_sales` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `reports_summary_daily_cinema_sales`(_start_date DATETIME)
BEGIN
DECLARE _report_name VARCHAR(60);
DECLARE _dt DATETIME;
DECLARE _date VARCHAR(20);
DECLARE _time VARCHAR(20);
SELECT `name` INTO _report_name FROM report WHERE id = 3;
SET _dt = NOW();
SET _date = DATE_FORMAT(_dt, '%m/%d/%Y');
SET _time = DATE_FORMAT(_dt, '%h:%i %p');
SELECT CONCAT('Date:  ', _date) as currentdate, CONCAT('Time:  ',_time) as currenttime, 
'' AS establishmentname,
IFNULL(_report_name, '') AS reportname, 
 CONCAT('For ', DATE_FORMAT(_start_date, '%m/%d/%Y')) AS fordate
FROM dual;
SELECT f.in_order, f.name, e.code, e.title, COUNT(cinema_seat_id) quantity, SUM(price) sales FROM movies_schedule_list_reserved_seat a, ticket b, 
movies_schedule_list c, movies_schedule d, movies e, cinema f
 WHERE a.ticket_id = b.id
and a.status = 1 AND a.movies_schedule_list_id = c.id AND c.movies_schedule_id = d.id
AND d.movie_date = _start_date AND d.movie_id = e.id AND d.cinema_id = f.id
GROUP BY f.id, e.id ORDER BY f.in_order;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reports_summary_reports_descriptions` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `reports_summary_reports_descriptions`()
BEGIN
	SELECT id, code, name, description FROM report ORDER BY code;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reports_teller_daily_sales` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `reports_teller_daily_sales`(_userid INT, _start_date DATETIME)
BEGIN
DECLARE _username VARCHAR(100);
DECLARE _report_name VARCHAR(60);
DECLARE _dt DATETIME;
DECLARE _date VARCHAR(20);
DECLARE _time VARCHAR(20);
SELECT userid INTO _username FROM users WHERE id = _userid;
SELECT `name` INTO _report_name FROM report WHERE id = 1;
SET _dt = NOW();
SET _date = DATE_FORMAT(_dt, '%m/%d/%Y');
SET _time = DATE_FORMAT(_dt, '%h:%i %p');
SELECT CONCAT('Date:  ', _date) as currentdate, CONCAT('Time:  ',_time) as currenttime, 
'' AS establishmentname,
IFNULL(_report_name, '') AS reportname, IFNULL(_username, '') AS username, 
 CONCAT('Sales Date: ', DATE_FORMAT(_start_date, '%m/%d/%Y')) AS salesdate,
'Ticket Seller : ___________________' as ticketseller, 'Manager :      ___________________' as manager,  
'Checked By : ___________________' as checkedby FROM dual;
SELECT c.movie_date, d.code, d.name, f.name, COUNT(a.cinema_seat_id), a.price, SUM(a.price) FROM movies_schedule_list_reserved_seat a, movies_schedule_list b, movies_schedule c, patrons d, 
ticket e, cinema f
WHERE a.movies_schedule_list_id = b.id AND b.movies_schedule_id = c.id 
AND a.patron_id = d.id AND a.ticket_id = e.id
AND c.cinema_id = f.id
AND DATEDIFF(_start_date, ticket_datetime) = 0
AND e.user_id = _userid
AND a.status = 1
AND c.movie_date = _start_date
GROUP BY c.movie_date, d.code, d.name, f.in_order, f.name, a.price
ORDER BY c.movie_date,  f.in_order, d.code;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reports_teller_daily_sales_all` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `reports_teller_daily_sales_all`(_start_date DATETIME)
BEGIN
DECLARE _report_name VARCHAR(60);
DECLARE _dt DATETIME;
DECLARE _date VARCHAR(20);
DECLARE _time VARCHAR(20);
SELECT `name` INTO _report_name FROM report WHERE id = 12;
SET _dt = NOW();
SET _date = DATE_FORMAT(_dt, '%m/%d/%Y');
SET _time = DATE_FORMAT(_dt, '%h:%i %p');
SELECT CONCAT('Date:  ', _date) as currentdate, CONCAT('Time:  ',_time) as currenttime, 
'' AS establishmentname,
IFNULL(_report_name, '') AS reportname, 
DATE_FORMAT(_start_date, '%m/%d/%Y') AS fordate
FROM dual;
SELECT h.userid, CONCAT(h.fname, ' ', h.mname, '.' , h.lname), d.code, d.name,  f.in_order, a.price,  COUNT(a.cinema_seat_id), SUM(a.price) FROM movies_schedule_list_reserved_seat a, movies_schedule_list b, 
movies_schedule c, patrons d, cinema f, ticket g, users h
WHERE a.movies_schedule_list_id = b.id AND b.movies_schedule_id = c.id AND a.patron_id = d.id AND cinema_id = f.id
AND a.ticket_id = g.id AND g.user_id = h.id
AND c.movie_date = _start_date GROUP BY h.id, a.patron_id, cinema_id,  a.price 
ORDER BY h.userid, d.name, f.in_order, a.price;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reports_teller_daily_sales_cinema` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `reports_teller_daily_sales_cinema`(_start_date DATETIME)
BEGIN
DECLARE _report_name VARCHAR(60);
DECLARE _dt DATETIME;
DECLARE _date VARCHAR(20);
DECLARE _time VARCHAR(20);
SELECT `name` INTO _report_name FROM report WHERE id = 13;
SET _dt = NOW();
SET _date = DATE_FORMAT(_dt, '%m/%d/%Y');
SET _time = DATE_FORMAT(_dt, '%h:%i %p');
SELECT CONCAT('Date:  ', _date) as currentdate, CONCAT('Time:  ',_time) as currenttime, 
'' AS establishmentname,
IFNULL(_report_name, '') AS reportname, 
DATE_FORMAT(_start_date, '%m/%d/%Y') AS fordate,
'Manager :      ___________________' as manager,  
'Checked By : ___________________' as checkedby 
FROM dual;
SELECT f.name, i.title, h.userid, CONCAT(h.fname, ' ', h.mname, '.' , h.lname), d.code, d.name,  f.in_order, a.price,  COUNT(a.cinema_seat_id), SUM(a.price) FROM movies_schedule_list_reserved_seat a, movies_schedule_list b, 
movies_schedule c, patrons d, cinema f, ticket g, users h, movies i
WHERE a.movies_schedule_list_id = b.id AND b.movies_schedule_id = c.id AND a.patron_id = d.id AND cinema_id = f.id
AND a.ticket_id = g.id AND g.user_id = h.id  AND c.movie_id = i.id
AND c.movie_date = _start_date GROUP BY cinema_id, i.id, h.id, a.patron_id, a.price 
ORDER BY f.in_order, i.title, h.userid, d.name, a.price;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reports_teller_daily_summary_sales` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `reports_teller_daily_summary_sales`(_start_date DATETIME)
BEGIN
DECLARE _report_name VARCHAR(60);
DECLARE _dt DATETIME;
DECLARE _date VARCHAR(20);
DECLARE _time VARCHAR(20);
SELECT `name` INTO _report_name FROM report WHERE id = 4;
SET _dt = NOW();
SET _date = DATE_FORMAT(_dt, '%m/%d/%Y');
SET _time = DATE_FORMAT(_dt, '%h:%i %p');
SELECT CONCAT('Date:  ', _date) as currentdate, CONCAT('Time:  ',_time) as currenttime, 
'' AS establishmentname,
IFNULL(_report_name, '') AS reportname, 
CONCAT('For Sales Date ', DATE_FORMAT(_start_date, '%m/%d/%Y')) AS forsalesdate,
'Manager :      ___________________' as manager,  
'Checked By : ___________________' as checkedby 
FROM dual;
SELECT e.userid, CONCAT(e.fname, ' ', e.mname, '. ', e.lname), d.movie_date, COUNT(a.cinema_seat_id), SUM(a.price)
FROM movies_schedule_list_reserved_seat a, ticket b, 
movies_schedule_list c, movies_schedule d, users e
 WHERE a.ticket_id = b.id
and a.status = 1 AND a.movies_schedule_list_id = c.id AND c.movies_schedule_id = d.id
AND b.user_id = e.id
AND DATEDIFF(b.ticket_datetime, _start_date) = 0 
GROUP BY b.user_id, d.movie_date;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `retrieve_cinemas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `retrieve_cinemas`()
BEGIN
	SELECT id, name FROM cinema ORDER BY in_order;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `retrieve_distributors` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `retrieve_distributors`(_movie_date DATETIME)
BEGIN
	SELECT e.id, e.code, e.name FROM movies_schedule_list b, 
	movies_schedule c, movies d, distributor e
	WHERE b.movies_schedule_id = c.id
	AND c.movie_id = d.id
	AND d.dist_id = e.id
	AND DATE(c.movie_date) = _movie_date
	GROUP BY e.code, e.name
	ORDER BY e.name ASC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `retrieve_movies` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `retrieve_movies`(_movie_date DATETIME, _cinema_id INT)
BEGIN
	SELECT a.id, code, title FROM movies a, movies_schedule b WHERE a.id = b.movie_id AND movie_date = _movie_date AND cinema_id = _cinema_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `retrieve_movies2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `retrieve_movies2`(_movie_date1 DateTime, _movie_date2 DateTime)
BEGIN
	SELECT a.id, a.code, a.title FROM movies a, movies_schedule b, movies_distributor c
	WHERE a.id = b.movie_id AND a.id = c.movie_id AND b.movie_date BETWEEN _movie_date1 AND _movie_date2
	GROUP BY a.id, a.code, a.title
	ORDER by a.code asc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `retrieve_movies_schedule` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `retrieve_movies_schedule`(_movie_date DATETIME)
BEGIN
SELECT a.id, cinema_id, in_order, capacity, MIN(d.start_time) start_time FROM movies_schedule a, cinema b, movies c, movies_schedule_list d 
WHERE movie_date = _movie_date 
AND a.cinema_id = b.id AND a.movie_id = c.id
AND a.id = d.movies_schedule_id GROUP BY a.id
ORDER BY b.in_order,  start_time;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `retrieve_movies_schedule_list_patron_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `retrieve_movies_schedule_list_patron_id`(_id INT, movie_date DATETIME)
BEGIN
SELECT f.*, g.code patron_code, g.name patron_name, g.seat_color patron_seat_color  FROM (
SELECT id, movies_schedule_list_id, patron_id, price base_price, is_default, price + SUM(ordinance_val) + SUM(surcharge_val) price,
SUM(ordinance_val) ordinance_price, SUM(surcharge_val) surcharge_price FROM (
SELECT a.*, IF(d.patron_id IS NULL, 0, IF (isordinance = 0, 0, IF(in_pesovalue, amount_val, a.price * amount_val))) ordinance_val,
IF(d.patron_id IS NULL, 0, IF (isordinance = 1, 0, IF(in_pesovalue, amount_val, a.price * amount_val))) surcharge_val FROM movies_schedule_list_patron a
LEFT OUTER JOIN 
(SELECT patron_id, amount_val, in_pesovalue, isordinance FROM movies_schedule_list_patron_ordinance_surcharge_view WHERE ( (with_enddate = 0 && movie_date >= effective_date) || (with_enddate = 1 && movie_date >= effective_date && movie_date <= end_date))
) d ON a.patron_id = d.patron_id WHERE a.id = _id) e
GROUP BY id) f, patrons g WHERE f.patron_id = g.id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `retrieve_movies_schedule_list_patron_mslid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `retrieve_movies_schedule_list_patron_mslid`(mlsid INT, movie_date DATETIME)
BEGIN
SELECT f.*, g.code patron_code, g.name patron_name, g.seat_color patron_seat_color  FROM (
SELECT id, movies_schedule_list_id, patron_id, price base_price, is_default, price + SUM(ordinance_val) + SUM(surcharge_val) price,
SUM(ordinance_val) ordinance_price, SUM(surcharge_val) surcharge_price FROM (
SELECT a.*, IF(d.patron_id IS NULL, 0, IF (isordinance = 0, 0, IF(in_pesovalue, amount_val, a.price * amount_val))) ordinance_val,
IF(d.patron_id IS NULL, 0, IF (isordinance = 1, 0, IF(in_pesovalue, amount_val, a.price * amount_val))) surcharge_val FROM movies_schedule_list_patron a
LEFT OUTER JOIN 
(SELECT patron_id, amount_val, in_pesovalue, isordinance FROM movies_schedule_list_patron_ordinance_surcharge_view WHERE 
( (with_enddate = 0 && movie_date >= effective_date) || (with_enddate = 1 && movie_date >= effective_date && movie_date <= end_date))
) d ON a.patron_id = d.patron_id WHERE a.movies_schedule_list_id = mlsid) e
GROUP BY id) f, patrons g WHERE f.patron_id = g.id ORDER BY is_default DESC, seat_position, patron_name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `retrieve_movies_schedule_list_patron_mslid_default` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `retrieve_movies_schedule_list_patron_mslid_default`(mlsid INT, movie_date DATETIME)
BEGIN
SELECT f.*, g.code patron_code, g.name patron_name, g.seat_color patron_seat_color  FROM (
SELECT id, movies_schedule_list_id, patron_id, price base_price, is_default, price + SUM(ordinance_val) + SUM(surcharge_val) price,
SUM(ordinance_val) ordinance_price, SUM(surcharge_val) surcharge_price FROM (
SELECT a.*, IF(d.patron_id IS NULL, 0, IF (isordinance = 0, 0, IF(in_pesovalue, amount_val, a.price * amount_val))) ordinance_val,
IF(d.patron_id IS NULL, 0, IF (isordinance = 1, 0, IF(in_pesovalue, amount_val, a.price * amount_val))) surcharge_val FROM movies_schedule_list_patron a
LEFT OUTER JOIN 
(SELECT patron_id, amount_val, in_pesovalue, isordinance FROM movies_schedule_list_patron_ordinance_surcharge_view WHERE ( (with_enddate = 0 && movie_date >= effective_date) || (with_enddate = 1 && movie_date >= effective_date && movie_date <= end_date))
) d ON a.patron_id = d.patron_id WHERE a.movies_schedule_list_id = mlsid AND is_default = 1) e
GROUP BY id) f, patrons g WHERE f.patron_id = g.id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `retrieve_movies_schedule_list_patron_mslid_first` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `retrieve_movies_schedule_list_patron_mslid_first`(mlsid INT, movie_date DATETIME)
BEGIN
SELECT f.*, g.code patron_code, g.name patron_name, g.seat_color patron_seat_color  FROM (
SELECT id, movies_schedule_list_id, patron_id, price base_price, is_default, price + SUM(ordinance_val) + SUM(surcharge_val) price,
SUM(ordinance_val) ordinance_price, SUM(surcharge_val) surcharge_price FROM (
SELECT a.*, IF(d.patron_id IS NULL, 0, IF (isordinance = 0, 0, IF(in_pesovalue, amount_val, a.price * amount_val))) ordinance_val,
IF(d.patron_id IS NULL, 0, IF (isordinance = 1, 0, IF(in_pesovalue, amount_val, a.price * amount_val))) surcharge_val FROM movies_schedule_list_patron a
LEFT OUTER JOIN 
(SELECT patron_id, amount_val, in_pesovalue, isordinance FROM movies_schedule_list_patron_ordinance_surcharge_view WHERE ( (with_enddate = 0 && movie_date >= effective_date) || (with_enddate = 1 && movie_date >= effective_date && movie_date <= end_date))
) d ON a.patron_id = d.patron_id WHERE a.movies_schedule_list_id = mlsid) e
GROUP BY id) f, patrons g WHERE f.patron_id = g.id LIMIT 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `retrieve_posterminal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `retrieve_posterminal`()
BEGIN
	SELECT id, terminal FROM tmp_pos_terminal ORDER BY terminal;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `retrieve_tellers` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `retrieve_tellers`()
BEGIN
SELECT id, userid, full_name, user_id IS NOT NULL FROM 
	(SELECT a.id, userid, CONCAT(fname, ' ', mname, '. ',  lname) full_name FROM users a, user_level b WHERE  
	a.user_level_id = b.id AND a.system_code = 2 AND b.system_code  = 2) c 
	LEFT OUTER JOIN
	(SELECT user_id FROM ticket GROUP BY user_id) d 
	ON c.id = user_id ORDER BY userid;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `retrieve_tellers_ticket` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `retrieve_tellers_ticket`(_ticket_date DATETIME)
BEGIN
	SELECT a.id, userid, CONCAT(fname, ' ', mname, '. ',  lname), true FROM users a, ticket b WHERE a.id = user_id AND DATE(ticket_datetime) = _ticket_date
	AND a.system_code = 2 GROUP BY a.id ORDER BY userid;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-09 11:52:13
